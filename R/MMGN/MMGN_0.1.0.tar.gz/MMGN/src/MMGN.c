#include <R.h>
#include <Rmath.h>
#include <math.h>
#include <stdio.h>
#include <R_ext/BLAS.h>
#include <stdlib.h>



/*
Get indices of elements  equal to a specific value in an array
group -  an array of int, which presents the group index for each predictor in group GMC
p - dimension of group
j - the specific value we want to seach the indices for
l - dimension of the output
*/
void build_sparse(double *u, double *v, int *omega, int *m, int *n, int *r, int *nv, int *rowind, int *colind, double *vals)
{

    int id1 = 0;
    int id2 = 0;
    
    for (int i = 0; i < *nv; i++)
    {
        // id1 = ceil(omega[i]/(*m));
        // id2 = omega[i] % (*m);
        // if (id2 == 0){
        //   id2 = *n;
        // }
        //   if (id1 < *n && id2 <*n){
        //   id1 = id1+1;
        // } 
        id1 = ceil(omega[i]/(*m))+1;
        id2 = omega[i] - (id1-1)*(*m);
        if(id2==0){
          id2 = *m;
          id1 = id1 -1;
        }

        //printf("id1 = : %d \n", id1);
        //printf("id2 = : %d \n", id2);
        for (int j = 0; j < 2*(*r); j++)
       {
        // get the row indices
          rowind[2*(*r)*i + j] = i+1;
          //printf("You entered: %d", rowind[2*(*r)*i+j]);
          //fprintf(stderr, "%s", "tau must be nonnegative!\n");
        // get the column indices
        // get the values 
          if (j<*r){
            colind[2*(*r)*i + j] = id2 + (*m)*j;
            vals[2*(*r)*i + j] = v[id1 + j*(*n)-1]; // (id1, j+1)-th entry of V, since j starts from 0
            
          }else{
            colind[2*(*r)*i+j] = (*r)*(*m)+(id1-1)*(*r)+(j-*r)+1;
            vals[2*(*r)*i+j] = u[id2 + (j-*r)*(*m)-1]; // (id2, j-r+1)-th entry of U
            //printf("You entered: %d \n", id2 + (j-*r)*(*m)-1);
          }             
       } 

    }
 
}









