#' MMGN for 1-bit matrix completion under the probit noise model with a data-driven approach
#' for selecting the rank constraint parameter r
#'
#' \code{MMGN_probit_auto}  implements MMGN for 1-bit matrix completion under the probit model
#' and automatically select the parameter r using a data driven approach.
#'
#' @param Y the observed binary data matrix, unobserved entries are coded as zero
#' @param ind_omega the indicator vector of observations (column-major vectorization)
#' @param sigma the noise level, assumed to be known
#' @param rSeq a grid of positive integer values for the rank parameter r (default: 1 to 5)
#' @param maxiters the maximum number of iterations (default: 500)
#' @param tol tolerance for early stopping (default: 1e-4)
#' @param build how to build the J matrix in the LS problem. Options: 'R'(default) or 'C'
#' @param rate the percentage of data  to be used as the training set (default: 0.8)
#' @param seed set seed for reproducibility (default: 2022)
#' @param stopping which criterion for early stopping.
#'                 objective: early stop if the relative change in the objective value is less than tol (default)
#'                 estimate: early stop if the relative change in the estimate (squared F-norm) is less than tol
#' @param alpha0 the initial stepsize of GN for backtracking linesearch
#' @return \code{U} the estimated factor matrix U at the selected r
#' @return \code{V} the estimated factor matrix V at the selected r. The estimated matrix M=UV'
#' @return \code{rhat} the optimal rank r, equal to the number of columns of U and V
#' @return \code{loglik} the log-likelihood at each value of rSeq
#' @return \code{iter} the number of iterations used for the MMGN algorithm to converge for estimating the underlying
#'                     matrix with the selected r
#' @return \code{obj} the objective value at each iteration for estimating the underlying
#'                     matrix with the selected r
#' @return \code{relchange} the relative change of the estimate/objective at each iteration for estimating the underlying
#'                     matrix with the selected r
#' @return \code{nBacktracks} the number of backtracking steps at each iteration for estimating the underlying
#'                     matrix with the selected r
#' @export
#'
MMGN_probit_auto <- function(Y, ind_omega, sigma, rSeq=1:5,  maxiters=5e2, tol=1e-4, build = 'R', rate=0.8, seed=1234, stopping='objective', alpha0=1){

  numR <- length(rSeq)

  f <- function(x) {return(pnorm(x, sd=sigma))}
  gradf <- function(x) {return(dnorm(x, sd=sigma))}

  # generate training/testing sets
  set.seed(seed)
  omega <- which(ind_omega > 0)
  training <- sample(omega, size=ceiling(rate*length(omega)))
  testing <- setdiff(omega, training)
  ind_train <- ind_test <- rep(0, m*n)
  ind_train[training] <- 1
  ind_test[testing] <- 1


  loglik <- rep(NA, numR)

  ## for initialization
  t <- proc.time()
  svd_out <- svd(Y)
  proc.time()- t

  D <- (1+Y)/2
  d <- D[ind_test>0]

  rhat <- 1;
  mll <- -Inf;
  U00 <- svd_out$u[, 1:rhat]%*%sqrt(diag(x=svd_out$d[1:rhat], nrow=rhat))
  V00 <- svd_out$v[, 1:rhat]%*%sqrt(diag(x=svd_out$d[1:rhat], nrow=rhat))

  #main loop for selecting r
  for (i in 1:numR) {
    # set r for this loop
    r <- rSeq[i]
    U0 <- svd_out$u[, 1:r]%*%sqrt(diag(x=svd_out$d[1:r], nrow=r))
    V0 <- svd_out$v[, 1:r]%*%sqrt(diag(x=svd_out$d[1:r], nrow=r))

    res <- MMGN_probit(Y, ind_train, sigma = sigma, R=r, U0=U0, V0=V0, maxiters = maxiters, tol=tol,
                       build = build, stopping=stopping, alpha0 = alpha0)

    Mhat <- res$U%*%t(res$V)

    # compute the log-likelihood on the testing set
    loglik[i] <- -obj_1bit(d, Mhat[ind_test>0], f)

    # for the overall
    if (loglik[i]>mll){
      rhat <- r
      mll <- loglik[i]
      U00 <- res$U
      V00 <- res$V
    }

  }

  res <- MMGN_probit(Y, ind_omega, sigma = sigma, R=rhat, U0=U00, V0=V00, maxiters = maxiters, tol=tol,
                     build = build, stopping=stopping, alpha0 = alpha0)

  iter <- res$iters

  return(list(U = res$U, V = res$V, rhat = rhat, loglik = loglik, iters=iter, obj = res$obj[1:iter],
              relchange = res$relchange[1:iter], nBacktracks = res$nBacktracks[1:iter]))
}
