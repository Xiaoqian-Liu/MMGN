#' MMGN for 1-bit matrix completion under the logistic noise model
#' 
#' \code{MMGN_logist} implements MMGN for 1-bit matrix completion under the logistic noise model,
#' given a specific rank R
#' 
#' @param Y the observed binary data matrix, unobserved entries are coded as zero
#' @param ind_omega the indicator vector of observations (column-major vectorization)
#' @param sigma the noise level, assumed to be known
#' @param R the target rank
#' @param U0 the initial value of the factor matrix U
#' @param V0 the initial value of the factor matrix V
#' @param maxiters maximum number of iterations
#' @param tol tolerance for the relative change in the objective value or the norm of the estiamte (for early stopping)
#' @param build how to build the J matrix in the LS problem. Options: 'R'(default) or 'C'
#' @param stopping which criterion for early stopping. 
#'                 objective: early stop if the relative change in the objective value is less than tol (default)
#'                 estimate: early stop if the relative change in the estimate (squared F-norm) is less than tol 
#' @param alpha0 the initial stepsize of GN for backtracking linesearch
#' @return \code{U} the estimated factor matrix U
#' @return \code{V} the estimated factor matrix V. The estimated matrix M=UV'
#' @return \code{iter} the number of iterations used for the MMGN algorithm to converge
#' @return \code{obj} the objective value at each iteration
#' @return \code{relchange} the relative change in the objective / estimate at each iteration
#' @return \code{alphas} the stepsize for the GN step at each iteration
#' @return \code{nBacktracks} the number of backtracking steps at each iteration
#' @export
#' 
MMGN_logist <- function(Y, ind_omega, sigma, R, U0, V0, maxiters=5e2, tol=1e-4, build='R', stopping = 'objective', alpha0=1){
  
  m <- nrow(Y)
  n <- ncol(Y)
  y <- Y[ind_omega>0]
  d <- (1+y)/2
  omega <- sort(which(ind_omega==1))
  
  f <- function(x) {return(plogis(x, scale = sigma))}
  gradf <- function(x) {return(dlogis(x, scale = sigma))}
  
  # initialization for MMGN
  Mhat_last <- U0%*%t(V0)
  mhat_last = Mhat_last[ind_omega>0]
  obj_last <- obj_1bit(d,mhat_last, f)
  
  
  #parameter for backtracking
  beta <- 0.5
  gamma <- 0.9
  L <- 1/(4*sigma^2) 
  
  obj <- rep(NA, maxiters)
  relchange <- rep(NA, maxiters)
  dec <- rep(NA, maxiters)
  alphas <- rep(NA, maxiters)
  nBacktracks <- rep(NA, maxiters)
  
  
  
  for (i in 1:maxiters) {
    
    # construct x in the LS problem
    x <- (4*sigma)*y*f(-y*mhat_last)
    if(build == 'C'){
      Phi <- build_sparse(U0, V0, omega)
    }else{
      # construct J in the LS problem
      Phi1 <- kronecker(V0, Diagonal(n))
      Phi1 <- Phi1[ind_omega>0, ]
      
      Phi2 <- kronecker(Diagonal(n), U0)
      Phi2 <- Phi2[ind_omega>0, ]
      
      Phi <- cbind(Phi1,Phi2)
    }
    
    # solve the LS problem using LSQR
    eta <- glmnet(Phi, x, lambda = 0, intercept = FALSE)$beta
    # get  du and dv
    du <- eta[1:(m*R)]
    dv <- eta[(m*R+1):(R*(m+n))]
    
    # recover dU and dV
    dU <- matrix(du,  nrow = m)
    dV <- t(matrix(dv, nrow = R))
    
    # update U and V with stepsize alpha chosen by backtracking
    alpha <- alpha0
    U1 <- U0 + alpha*dU
    V1 <- V0 + alpha*dV
    
    # compute dU V + U dV in the backtracking condition
    G <- dU%*%t(V0)+ U0%*%t(dV)
    g <- G[ind_omega>0]
    
    dec[i] <- -L*x%*%g
    
    # start backtracking
    nBacktrack <- 0
    Mhat <- U1%*%t(V1)
    mhat <- Mhat[ind_omega>0]
    obj_new <- obj_1bit(d, mhat, f)
    while (obj_new > obj_last + beta*alpha*dec[i] && nBacktrack<=100) {
      alpha <- gamma*alpha
      U1 <- U0 + alpha*dU
      V1 <- V0 + alpha*dV
      Mhat <- U1%*%t(V1)
      mhat <- Mhat[ind_omega>0]
      obj_new <- obj_1bit(d, mhat, f)
      nBacktrack <- nBacktrack +1
    }
    
    
    # save some output
    obj[i] <- obj_new
    alphas[i] <- alpha
    nBacktracks[i] <- nBacktrack
    
    # relative change according to stopping 
    if (stopping == 'objective'){
      relchange[i] <- abs((obj_last - obj_new)/(obj_last + 1e-15))
    }else{
      relchange[i] <- norm(Mhat - Mhat_last, "F")^2/norm(Mhat_last, "F")^2      
    }
    
    # earlier stopping
    if(relchange[i]< tol){
      break
    }
    
    
    # update for the next iteration
    U0 <- U1
    V0 <- V1
    mhat_last <- Mhat[ind_omega>0]
    obj_last <- obj_new
    
    
  }
  
  return(list(U = U1, V = V1, iters=i, obj = obj[1:i],
              relchange = relchange[1:i], 
              nBacktracks = nBacktracks[1:i]))
}
