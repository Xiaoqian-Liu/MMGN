#' @param U the U factor matrix
#' @param V the V factor matrix
#' @param omega the set of observation indecies
#' @useDynLib MMGN
#' @export
build_sparse <- function(U, V, omega){
  m <- nrow(U)
  n <- nrow(V)
  r <- ncol(U)
  nv <- length(omega)

  m <- as.integer(m)
  n <- as.integer(n)
  r <- as.integer(r)
  nv <- as.integer(nv)

  u <- as.vector(U)
  v <- as.vector(V)

  rowind <- rep(0, 2*r*nv)
  colind <- rep(0, 2*r*nv)
  vals <- rep(0, 2*r*nv)

  rowind <- as.integer(rowind)
  colind <- as.integer(colind)
  omega <- as.integer(omega)

  sol <- .C("build_sparse", u=u, v=v, omega=omega, m=m, n=n, r=r, nv=nv,
             rowind=rowind, colind=colind, vals=vals, PACKAGE = 'MMGN')

  J <- sparseMatrix(i=sol$rowind, j=sol$colind, x=sol$vals, dims=c(nv, (m+n)*r))
  return(J)
}


