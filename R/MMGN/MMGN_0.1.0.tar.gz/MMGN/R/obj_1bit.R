#' The objective function of the 1-bit matrix completion problem 
#' 
#' \code{obj_1bit} computes the loss (negative log-likelihood) in the 1Bit matrix completion problem 
#' 
#' @param d the vector of observations in the D matrix, D=(1+Y)/2
#' @param m the vector of observations in the current estimate of the underlying matrix 
#' @param f the CDF of the noise (probit or logistic)
#' @return the objective value
#' @export
#' 
obj_1bit <- function(d, m, f){
  
  
  
  m1 <- m[d==1]
  m0 <- m[d==0]
  
  
  obj <- -sum(log(f(m1))) - sum(log(1-f(m0)))
  
  return(obj)
}